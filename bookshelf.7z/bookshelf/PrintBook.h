#ifndef PRINTBOOK_H
#define PRINTBOOK_H
#include <iostream>
#include <string>
#include "BookB.h"

using namespace std;

class PrintBook:public Book{
	private:
		int printPages;
	public:
		PrintBook():Book(){
			printPages=0;
		}
		int getPrintPages(){
			return printPages;
		}
		void setName(string s){
			Name = s;
		}
		void setPages(int p){
			Pages = p;
			printPages = p/16;
		}
};

#endif
